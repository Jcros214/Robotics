/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       jon                                                       */
/*    Created:      Mon Sep 20 2021                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    1, 11, 9, 19    
// Controller1          controller                    
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

// Setting vars:

// Gives a small deadzone for the controller to prevent drifting ( % )
float controllerDead = 5 / 100;

// Change how fast the robot accelerates (1 + %)
float accelRate = 1.5;


/*
LM 10 RM

intake is blue

lift motors are red

*/


int startTime, nowTime; 
float accel;
bool isStartingBool;


using namespace vex;



int main() {
  if ( controllerDead < Controller1.Axis3.position() && Controller1.Axis3.position() > -controllerDead) { // if controller joystick is outside of deadzone and this this is not the start of accelaeration
    if (isStartingBool) {
        startTime = vexSystemTimeGet();
        isStartingBool = false;
    } else {
        nowTime = startTime - vexSystemTimeGet();

        nowTime = 
        
        Drivetrain.setDriveVelocity(, percentUnits::pct);
    }
  }
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  
}
