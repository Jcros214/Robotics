/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       jon                                                       */
/*    Created:      Mon Sep 20 2021                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    1, 11, 9, 19    
// Controller1          controller                    
// Lift                 motor_group   10, 20          
// Intake               motor         21              
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

// Setting vars:

// Gives a small deadzone for the controller to prevent drifting ( % )
float controllerDead = 5 / 100;

// Change how fast the robot accelerates (duration)
float accelRate = 1.5;


/*
LM 10 RM

intake is blue

lift motors are red

*/


int startTime, nowTime, avg; 
int startTimeLift, nowTimeLift; 
float accel;
bool isStartingBool, isStartingBoolLift;


using namespace vex;



int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  while(1){
    avg = (Controller1.Axis3.position() + Controller1.Axis4.position()) / 2;
    if ( controllerDead < avg && avg > -controllerDead) { // if controller joystick is outside of deadzone and this this is not the start of accelaeration
      if (isStartingBool) {
          startTime = vexSystemTimeGet();
          isStartingBool = false;
      } else {
          nowTime = (startTime - vexSystemTimeGet())/accelRate;
          Drivetrain.setDriveVelocity(nowTime*Controller1.Axis3.position(), percentUnits::pct);
          Drivetrain.setTurnVelocity(nowTime*Controller1.Axis4.position(), percentUnits::pct);
      }
    } else { 
        Drivetrain.setDriveVelocity(0, percentUnits::pct); 
        isStartingBool = true;
      } 


/*
    if (Controller1.ButtonL1.pressing()) {
      if (isStartingBoolLift) {
          startTimeLift = vexSystemTimeGet();
          isStartingBoolLift = false;
      } else {
          nowTimeLift = (startTimeLift - vexSystemTimeGet())/accelRate;
      }
    } else { Lift.setVelocity(nowTimeLift, percentUnits units) } 

    if (Controller1.ButtonL2.pressing()) {
      if (isStartingBoolLift) {
          startTimeLift = vexSystemTimeGet();
          isStartingBoolLift = false;
      } else {
          nowTimeLift = (startTimeLift - vexSystemTimeGet())/accelRate;
      }
    } else { Drivetrain.setDriveVelocity(0, percentUnits::pct); } 
*/

  

  }


}
